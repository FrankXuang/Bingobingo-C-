﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_BingoBingo_
{
    internal class Globar
    {
        internal static bool 超級獎項 = false;
        internal static int 金額;
        internal static double 總金額;
        internal static int 猜大小金額;
        internal static double 猜單雙金額;
        internal static double 全部總金額;
        internal static double 利潤;
        internal static int winTimes;
        internal static int 星數;
        internal static int 包牌星數;
        internal static int 投注金額 = 25;
        internal static bool 猜大 = false;
        internal static bool 猜小 = false;
        internal static bool 猜和 = false;
        internal static bool 猜單 = false;
        internal static bool 猜小單 = false;
        internal static bool 猜雙 = false;
        internal static bool 猜小雙 = false;

    }
}
