﻿namespace Homework_BingoBingo_
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn兌獎 = new System.Windows.Forms.Button();
            this.lblNum20 = new System.Windows.Forms.Label();
            this.lblNum19 = new System.Windows.Forms.Label();
            this.lblNum18 = new System.Windows.Forms.Label();
            this.lblNum17 = new System.Windows.Forms.Label();
            this.lblNum16 = new System.Windows.Forms.Label();
            this.lblNum15 = new System.Windows.Forms.Label();
            this.lblNum14 = new System.Windows.Forms.Label();
            this.lblNum13 = new System.Windows.Forms.Label();
            this.lblNum12 = new System.Windows.Forms.Label();
            this.lblNum11 = new System.Windows.Forms.Label();
            this.btnPrice = new System.Windows.Forms.Button();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.lblNum4 = new System.Windows.Forms.Label();
            this.lblNum5 = new System.Windows.Forms.Label();
            this.lblNum6 = new System.Windows.Forms.Label();
            this.lblNum7 = new System.Windows.Forms.Label();
            this.lblNum8 = new System.Windows.Forms.Label();
            this.lblNum9 = new System.Windows.Forms.Label();
            this.lblNum10 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.btn電腦選碼 = new System.Windows.Forms.Button();
            this.btnMore = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.listBoxInformation = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.combo基本星數 = new System.Windows.Forms.ComboBox();
            this.chk超級獎號 = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chk超級包牌獎號 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt包牌次數 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.radio猜大小不玩 = new System.Windows.Forms.RadioButton();
            this.radio猜小 = new System.Windows.Forms.RadioButton();
            this.radio猜大 = new System.Windows.Forms.RadioButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.radio不玩 = new System.Windows.Forms.RadioButton();
            this.radio猜小雙 = new System.Windows.Forms.RadioButton();
            this.radio猜小單 = new System.Windows.Forms.RadioButton();
            this.radio猜和 = new System.Windows.Forms.RadioButton();
            this.radio猜雙數 = new System.Windows.Forms.RadioButton();
            this.radio猜單數 = new System.Windows.Forms.RadioButton();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.time電腦選號 = new System.Windows.Forms.Timer(this.components);
            this.lbl倒數 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.combo幾星電腦選碼 = new System.Windows.Forms.ComboBox();
            this.btn玩家號碼顯示 = new System.Windows.Forms.Button();
            this.lblPlay1 = new System.Windows.Forms.Label();
            this.group號碼 = new System.Windows.Forms.GroupBox();
            this.lblPlay10 = new System.Windows.Forms.Label();
            this.lblPlay9 = new System.Windows.Forms.Label();
            this.lblPlay8 = new System.Windows.Forms.Label();
            this.lblPlay7 = new System.Windows.Forms.Label();
            this.lblPlay6 = new System.Windows.Forms.Label();
            this.lblPlay5 = new System.Windows.Forms.Label();
            this.lblPlay4 = new System.Windows.Forms.Label();
            this.lblPlay3 = new System.Windows.Forms.Label();
            this.lblPlay2 = new System.Windows.Forms.Label();
            this.textMoney = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.玩法說明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基本玩法ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.超級獎號ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.猜大小ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.猜單雙ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.按鈕說明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.group號碼.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn兌獎);
            this.groupBox1.Controls.Add(this.lblNum20);
            this.groupBox1.Controls.Add(this.lblNum19);
            this.groupBox1.Controls.Add(this.lblNum18);
            this.groupBox1.Controls.Add(this.lblNum17);
            this.groupBox1.Controls.Add(this.lblNum16);
            this.groupBox1.Controls.Add(this.lblNum15);
            this.groupBox1.Controls.Add(this.lblNum14);
            this.groupBox1.Controls.Add(this.lblNum13);
            this.groupBox1.Controls.Add(this.lblNum12);
            this.groupBox1.Controls.Add(this.lblNum11);
            this.groupBox1.Controls.Add(this.btnPrice);
            this.groupBox1.Controls.Add(this.lblNum3);
            this.groupBox1.Controls.Add(this.lblNum4);
            this.groupBox1.Controls.Add(this.lblNum5);
            this.groupBox1.Controls.Add(this.lblNum6);
            this.groupBox1.Controls.Add(this.lblNum7);
            this.groupBox1.Controls.Add(this.lblNum8);
            this.groupBox1.Controls.Add(this.lblNum9);
            this.groupBox1.Controls.Add(this.lblNum10);
            this.groupBox1.Controls.Add(this.lblNum2);
            this.groupBox1.Controls.Add(this.lblNum1);
            this.groupBox1.Location = new System.Drawing.Point(151, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(764, 121);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BingoBingo";
            // 
            // btn兌獎
            // 
            this.btn兌獎.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn兌獎.Location = new System.Drawing.Point(600, 78);
            this.btn兌獎.Name = "btn兌獎";
            this.btn兌獎.Size = new System.Drawing.Size(122, 35);
            this.btn兌獎.TabIndex = 22;
            this.btn兌獎.Text = "兌獎";
            this.btn兌獎.UseVisualStyleBackColor = true;
            this.btn兌獎.Click += new System.EventHandler(this.btn兌獎_Click);
            // 
            // lblNum20
            // 
            this.lblNum20.BackColor = System.Drawing.Color.IndianRed;
            this.lblNum20.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum20.Location = new System.Drawing.Point(538, 78);
            this.lblNum20.Name = "lblNum20";
            this.lblNum20.Size = new System.Drawing.Size(39, 34);
            this.lblNum20.TabIndex = 21;
            this.lblNum20.Text = "00";
            this.lblNum20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum19
            // 
            this.lblNum19.BackColor = System.Drawing.Color.White;
            this.lblNum19.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum19.Location = new System.Drawing.Point(483, 78);
            this.lblNum19.Name = "lblNum19";
            this.lblNum19.Size = new System.Drawing.Size(39, 34);
            this.lblNum19.TabIndex = 20;
            this.lblNum19.Text = "00";
            this.lblNum19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum18
            // 
            this.lblNum18.BackColor = System.Drawing.Color.White;
            this.lblNum18.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum18.Location = new System.Drawing.Point(425, 78);
            this.lblNum18.Name = "lblNum18";
            this.lblNum18.Size = new System.Drawing.Size(39, 34);
            this.lblNum18.TabIndex = 19;
            this.lblNum18.Text = "00";
            this.lblNum18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum17
            // 
            this.lblNum17.BackColor = System.Drawing.Color.White;
            this.lblNum17.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum17.Location = new System.Drawing.Point(363, 78);
            this.lblNum17.Name = "lblNum17";
            this.lblNum17.Size = new System.Drawing.Size(39, 34);
            this.lblNum17.TabIndex = 18;
            this.lblNum17.Text = "00";
            this.lblNum17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum16
            // 
            this.lblNum16.BackColor = System.Drawing.Color.White;
            this.lblNum16.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum16.Location = new System.Drawing.Point(303, 78);
            this.lblNum16.Name = "lblNum16";
            this.lblNum16.Size = new System.Drawing.Size(39, 34);
            this.lblNum16.TabIndex = 17;
            this.lblNum16.Text = "00";
            this.lblNum16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum15
            // 
            this.lblNum15.BackColor = System.Drawing.Color.White;
            this.lblNum15.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum15.Location = new System.Drawing.Point(247, 78);
            this.lblNum15.Name = "lblNum15";
            this.lblNum15.Size = new System.Drawing.Size(39, 34);
            this.lblNum15.TabIndex = 16;
            this.lblNum15.Text = "00";
            this.lblNum15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum14
            // 
            this.lblNum14.BackColor = System.Drawing.Color.White;
            this.lblNum14.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum14.Location = new System.Drawing.Point(192, 78);
            this.lblNum14.Name = "lblNum14";
            this.lblNum14.Size = new System.Drawing.Size(39, 34);
            this.lblNum14.TabIndex = 15;
            this.lblNum14.Text = "00";
            this.lblNum14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum13
            // 
            this.lblNum13.BackColor = System.Drawing.Color.White;
            this.lblNum13.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum13.Location = new System.Drawing.Point(138, 78);
            this.lblNum13.Name = "lblNum13";
            this.lblNum13.Size = new System.Drawing.Size(39, 34);
            this.lblNum13.TabIndex = 14;
            this.lblNum13.Text = "00";
            this.lblNum13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum12
            // 
            this.lblNum12.BackColor = System.Drawing.Color.White;
            this.lblNum12.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum12.Location = new System.Drawing.Point(77, 78);
            this.lblNum12.Name = "lblNum12";
            this.lblNum12.Size = new System.Drawing.Size(39, 34);
            this.lblNum12.TabIndex = 13;
            this.lblNum12.Text = "00";
            this.lblNum12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum11
            // 
            this.lblNum11.BackColor = System.Drawing.Color.White;
            this.lblNum11.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum11.Location = new System.Drawing.Point(23, 78);
            this.lblNum11.Name = "lblNum11";
            this.lblNum11.Size = new System.Drawing.Size(39, 34);
            this.lblNum11.TabIndex = 12;
            this.lblNum11.Text = "00";
            this.lblNum11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPrice
            // 
            this.btnPrice.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnPrice.Location = new System.Drawing.Point(600, 32);
            this.btnPrice.Name = "btnPrice";
            this.btnPrice.Size = new System.Drawing.Size(122, 35);
            this.btnPrice.TabIndex = 10;
            this.btnPrice.Text = "開獎號碼";
            this.btnPrice.UseVisualStyleBackColor = true;
            this.btnPrice.Click += new System.EventHandler(this.btnPrice_Click);
            // 
            // lblNum3
            // 
            this.lblNum3.BackColor = System.Drawing.Color.White;
            this.lblNum3.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum3.Location = new System.Drawing.Point(135, 32);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(39, 34);
            this.lblNum3.TabIndex = 9;
            this.lblNum3.Text = "00";
            this.lblNum3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum4
            // 
            this.lblNum4.BackColor = System.Drawing.Color.White;
            this.lblNum4.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum4.Location = new System.Drawing.Point(192, 32);
            this.lblNum4.Name = "lblNum4";
            this.lblNum4.Size = new System.Drawing.Size(39, 34);
            this.lblNum4.TabIndex = 8;
            this.lblNum4.Text = "00";
            this.lblNum4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum5
            // 
            this.lblNum5.BackColor = System.Drawing.Color.White;
            this.lblNum5.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum5.Location = new System.Drawing.Point(247, 32);
            this.lblNum5.Name = "lblNum5";
            this.lblNum5.Size = new System.Drawing.Size(39, 34);
            this.lblNum5.TabIndex = 7;
            this.lblNum5.Text = "00";
            this.lblNum5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum6
            // 
            this.lblNum6.BackColor = System.Drawing.Color.White;
            this.lblNum6.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum6.Location = new System.Drawing.Point(303, 32);
            this.lblNum6.Name = "lblNum6";
            this.lblNum6.Size = new System.Drawing.Size(39, 34);
            this.lblNum6.TabIndex = 6;
            this.lblNum6.Text = "00";
            this.lblNum6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum7
            // 
            this.lblNum7.BackColor = System.Drawing.Color.White;
            this.lblNum7.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum7.Location = new System.Drawing.Point(363, 32);
            this.lblNum7.Name = "lblNum7";
            this.lblNum7.Size = new System.Drawing.Size(39, 34);
            this.lblNum7.TabIndex = 5;
            this.lblNum7.Text = "00";
            this.lblNum7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum8
            // 
            this.lblNum8.BackColor = System.Drawing.Color.White;
            this.lblNum8.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum8.Location = new System.Drawing.Point(425, 32);
            this.lblNum8.Name = "lblNum8";
            this.lblNum8.Size = new System.Drawing.Size(39, 34);
            this.lblNum8.TabIndex = 4;
            this.lblNum8.Text = "00";
            this.lblNum8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum9
            // 
            this.lblNum9.BackColor = System.Drawing.Color.White;
            this.lblNum9.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum9.Location = new System.Drawing.Point(484, 32);
            this.lblNum9.Name = "lblNum9";
            this.lblNum9.Size = new System.Drawing.Size(39, 34);
            this.lblNum9.TabIndex = 3;
            this.lblNum9.Text = "00";
            this.lblNum9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum10
            // 
            this.lblNum10.BackColor = System.Drawing.Color.White;
            this.lblNum10.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum10.Location = new System.Drawing.Point(538, 32);
            this.lblNum10.Name = "lblNum10";
            this.lblNum10.Size = new System.Drawing.Size(39, 34);
            this.lblNum10.TabIndex = 2;
            this.lblNum10.Text = "00";
            this.lblNum10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum2
            // 
            this.lblNum2.BackColor = System.Drawing.Color.White;
            this.lblNum2.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum2.Location = new System.Drawing.Point(77, 32);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(39, 34);
            this.lblNum2.TabIndex = 1;
            this.lblNum2.Text = "00";
            this.lblNum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum1
            // 
            this.lblNum1.BackColor = System.Drawing.Color.White;
            this.lblNum1.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNum1.Location = new System.Drawing.Point(23, 32);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(39, 34);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "00";
            this.lblNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn電腦選碼
            // 
            this.btn電腦選碼.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn電腦選碼.Location = new System.Drawing.Point(202, 16);
            this.btn電腦選碼.Name = "btn電腦選碼";
            this.btn電腦選碼.Size = new System.Drawing.Size(122, 23);
            this.btn電腦選碼.TabIndex = 22;
            this.btn電腦選碼.Text = "電腦選碼";
            this.btn電腦選碼.UseVisualStyleBackColor = true;
            this.btn電腦選碼.Click += new System.EventHandler(this.btn電腦選碼_Click);
            // 
            // btnMore
            // 
            this.btnMore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnMore.Location = new System.Drawing.Point(663, 20);
            this.btnMore.Name = "btnMore";
            this.btnMore.Size = new System.Drawing.Size(155, 23);
            this.btnMore.TabIndex = 13;
            this.btnMore.Text = "包牌(直接兌獎";
            this.btnMore.UseVisualStyleBackColor = false;
            this.btnMore.Click += new System.EventHandler(this.btnMore_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(979, 614);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(122, 29);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "結束";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1星",
            "2星",
            "3星",
            "4星",
            "5星",
            "6星",
            "7星",
            "8星",
            "9星",
            "10星"});
            this.comboBox1.Location = new System.Drawing.Point(84, 20);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(210, 24);
            this.comboBox1.TabIndex = 14;
            // 
            // listBoxInformation
            // 
            this.listBoxInformation.FormattingEnabled = true;
            this.listBoxInformation.ItemHeight = 16;
            this.listBoxInformation.Location = new System.Drawing.Point(457, 267);
            this.listBoxInformation.Name = "listBoxInformation";
            this.listBoxInformation.Size = new System.Drawing.Size(663, 324);
            this.listBoxInformation.TabIndex = 4;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(84, 156);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1001, 89);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.combo基本星數);
            this.tabPage1.Controls.Add(this.chk超級獎號);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(993, 59);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "基本";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "星數玩法";
            // 
            // combo基本星數
            // 
            this.combo基本星數.FormattingEnabled = true;
            this.combo基本星數.Items.AddRange(new object[] {
            "一星",
            "二星",
            "三星",
            "四星",
            "五星",
            "六星",
            "七星",
            "八星",
            "九星",
            "十星"});
            this.combo基本星數.Location = new System.Drawing.Point(110, 20);
            this.combo基本星數.Name = "combo基本星數";
            this.combo基本星數.Size = new System.Drawing.Size(367, 24);
            this.combo基本星數.TabIndex = 12;
            // 
            // chk超級獎號
            // 
            this.chk超級獎號.AutoSize = true;
            this.chk超級獎號.Location = new System.Drawing.Point(503, 22);
            this.chk超級獎號.Name = "chk超級獎號";
            this.chk超級獎號.Size = new System.Drawing.Size(90, 20);
            this.chk超級獎號.TabIndex = 11;
            this.chk超級獎號.Text = "超級獎號";
            this.chk超級獎號.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chk超級包牌獎號);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txt包牌次數);
            this.tabPage2.Controls.Add(this.btnMore);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(993, 59);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "包牌";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chk超級包牌獎號
            // 
            this.chk超級包牌獎號.AutoSize = true;
            this.chk超級包牌獎號.Location = new System.Drawing.Point(550, 22);
            this.chk超級包牌獎號.Name = "chk超級包牌獎號";
            this.chk超級包牌獎號.Size = new System.Drawing.Size(90, 20);
            this.chk超級包牌獎號.TabIndex = 18;
            this.chk超級包牌獎號.Text = "超級獎號";
            this.chk超級包牌獎號.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(327, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "次數";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "星級";
            // 
            // txt包牌次數
            // 
            this.txt包牌次數.Location = new System.Drawing.Point(372, 17);
            this.txt包牌次數.Name = "txt包牌次數";
            this.txt包牌次數.Size = new System.Drawing.Size(149, 27);
            this.txt包牌次數.TabIndex = 15;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.radio猜大小不玩);
            this.tabPage3.Controls.Add(this.radio猜小);
            this.tabPage3.Controls.Add(this.radio猜大);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(993, 59);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "猜大小";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // radio猜大小不玩
            // 
            this.radio猜大小不玩.AutoSize = true;
            this.radio猜大小不玩.Location = new System.Drawing.Point(266, 23);
            this.radio猜大小不玩.Name = "radio猜大小不玩";
            this.radio猜大小不玩.Size = new System.Drawing.Size(57, 20);
            this.radio猜大小不玩.TabIndex = 14;
            this.radio猜大小不玩.TabStop = true;
            this.radio猜大小不玩.Text = "不玩";
            this.radio猜大小不玩.UseVisualStyleBackColor = true;
            // 
            // radio猜小
            // 
            this.radio猜小.AutoSize = true;
            this.radio猜小.Location = new System.Drawing.Point(163, 23);
            this.radio猜小.Name = "radio猜小";
            this.radio猜小.Size = new System.Drawing.Size(57, 20);
            this.radio猜小.TabIndex = 13;
            this.radio猜小.TabStop = true;
            this.radio猜小.Text = "猜小";
            this.radio猜小.UseVisualStyleBackColor = true;
            // 
            // radio猜大
            // 
            this.radio猜大.AutoSize = true;
            this.radio猜大.Location = new System.Drawing.Point(67, 23);
            this.radio猜大.Name = "radio猜大";
            this.radio猜大.Size = new System.Drawing.Size(57, 20);
            this.radio猜大.TabIndex = 12;
            this.radio猜大.TabStop = true;
            this.radio猜大.Text = "猜大";
            this.radio猜大.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.radio不玩);
            this.tabPage4.Controls.Add(this.radio猜小雙);
            this.tabPage4.Controls.Add(this.radio猜小單);
            this.tabPage4.Controls.Add(this.radio猜和);
            this.tabPage4.Controls.Add(this.radio猜雙數);
            this.tabPage4.Controls.Add(this.radio猜單數);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(993, 59);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "猜單雙";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // radio不玩
            // 
            this.radio不玩.AutoSize = true;
            this.radio不玩.Location = new System.Drawing.Point(606, 21);
            this.radio不玩.Name = "radio不玩";
            this.radio不玩.Size = new System.Drawing.Size(57, 20);
            this.radio不玩.TabIndex = 18;
            this.radio不玩.TabStop = true;
            this.radio不玩.Text = "不玩";
            this.radio不玩.UseVisualStyleBackColor = true;
            // 
            // radio猜小雙
            // 
            this.radio猜小雙.AutoSize = true;
            this.radio猜小雙.Location = new System.Drawing.Point(382, 21);
            this.radio猜小雙.Name = "radio猜小雙";
            this.radio猜小雙.Size = new System.Drawing.Size(73, 20);
            this.radio猜小雙.TabIndex = 17;
            this.radio猜小雙.TabStop = true;
            this.radio猜小雙.Text = "猜小雙";
            this.radio猜小雙.UseVisualStyleBackColor = true;
            // 
            // radio猜小單
            // 
            this.radio猜小單.AutoSize = true;
            this.radio猜小單.Location = new System.Drawing.Point(156, 21);
            this.radio猜小單.Name = "radio猜小單";
            this.radio猜小單.Size = new System.Drawing.Size(73, 20);
            this.radio猜小單.TabIndex = 16;
            this.radio猜小單.TabStop = true;
            this.radio猜小單.Text = "猜小單";
            this.radio猜小單.UseVisualStyleBackColor = true;
            // 
            // radio猜和
            // 
            this.radio猜和.AutoSize = true;
            this.radio猜和.Location = new System.Drawing.Point(504, 21);
            this.radio猜和.Name = "radio猜和";
            this.radio猜和.Size = new System.Drawing.Size(57, 20);
            this.radio猜和.TabIndex = 15;
            this.radio猜和.TabStop = true;
            this.radio猜和.Text = "猜和";
            this.radio猜和.UseVisualStyleBackColor = true;
            // 
            // radio猜雙數
            // 
            this.radio猜雙數.AutoSize = true;
            this.radio猜雙數.Location = new System.Drawing.Point(271, 21);
            this.radio猜雙數.Name = "radio猜雙數";
            this.radio猜雙數.Size = new System.Drawing.Size(73, 20);
            this.radio猜雙數.TabIndex = 14;
            this.radio猜雙數.TabStop = true;
            this.radio猜雙數.Text = "猜雙數";
            this.radio猜雙數.UseVisualStyleBackColor = true;
            // 
            // radio猜單數
            // 
            this.radio猜單數.AutoSize = true;
            this.radio猜單數.Location = new System.Drawing.Point(41, 21);
            this.radio猜單數.Name = "radio猜單數";
            this.radio猜單數.Size = new System.Drawing.Size(73, 20);
            this.radio猜單數.TabIndex = 13;
            this.radio猜單數.TabStop = true;
            this.radio猜單數.Text = "猜單數";
            this.radio猜單數.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(819, 614);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(122, 29);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "清空列表";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(493, 614);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(122, 29);
            this.btnPrint.TabIndex = 7;
            this.btnPrint.Text = "列印";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // time電腦選號
            // 
            this.time電腦選號.Interval = 1000;
            this.time電腦選號.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lbl倒數
            // 
            this.lbl倒數.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.lbl倒數.Font = new System.Drawing.Font("標楷體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl倒數.Location = new System.Drawing.Point(958, 45);
            this.lbl倒數.Name = "lbl倒數";
            this.lbl倒數.Size = new System.Drawing.Size(62, 44);
            this.lbl倒數.TabIndex = 8;
            this.lbl倒數.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1026, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "秒";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.combo幾星電腦選碼);
            this.groupBox2.Controls.Add(this.btn電腦選碼);
            this.groupBox2.Location = new System.Drawing.Point(29, 323);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(408, 46);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "電腦選碼(基本玩法)(包牌直接點包牌";
            // 
            // combo幾星電腦選碼
            // 
            this.combo幾星電腦選碼.FormattingEnabled = true;
            this.combo幾星電腦選碼.Items.AddRange(new object[] {
            "一星",
            "二星",
            "三星",
            "四星",
            "五星",
            "六星",
            "七星",
            "八星",
            "九星",
            "十星"});
            this.combo幾星電腦選碼.Location = new System.Drawing.Point(54, 16);
            this.combo幾星電腦選碼.Name = "combo幾星電腦選碼";
            this.combo幾星電腦選碼.Size = new System.Drawing.Size(121, 24);
            this.combo幾星電腦選碼.TabIndex = 23;
            // 
            // btn玩家號碼顯示
            // 
            this.btn玩家號碼顯示.Location = new System.Drawing.Point(655, 614);
            this.btn玩家號碼顯示.Name = "btn玩家號碼顯示";
            this.btn玩家號碼顯示.Size = new System.Drawing.Size(122, 29);
            this.btn玩家號碼顯示.TabIndex = 24;
            this.btn玩家號碼顯示.Text = "顯示";
            this.btn玩家號碼顯示.UseVisualStyleBackColor = true;
            this.btn玩家號碼顯示.Click += new System.EventHandler(this.btn玩家號碼顯示_Click);
            // 
            // lblPlay1
            // 
            this.lblPlay1.BackColor = System.Drawing.Color.White;
            this.lblPlay1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay1.Location = new System.Drawing.Point(16, 22);
            this.lblPlay1.Name = "lblPlay1";
            this.lblPlay1.Size = new System.Drawing.Size(31, 30);
            this.lblPlay1.TabIndex = 25;
            this.lblPlay1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // group號碼
            // 
            this.group號碼.Controls.Add(this.lblPlay10);
            this.group號碼.Controls.Add(this.lblPlay9);
            this.group號碼.Controls.Add(this.lblPlay8);
            this.group號碼.Controls.Add(this.lblPlay7);
            this.group號碼.Controls.Add(this.lblPlay6);
            this.group號碼.Controls.Add(this.lblPlay5);
            this.group號碼.Controls.Add(this.lblPlay4);
            this.group號碼.Controls.Add(this.lblPlay3);
            this.group號碼.Controls.Add(this.lblPlay2);
            this.group號碼.Controls.Add(this.lblPlay1);
            this.group號碼.Location = new System.Drawing.Point(29, 245);
            this.group號碼.Name = "group號碼";
            this.group號碼.Size = new System.Drawing.Size(408, 76);
            this.group號碼.TabIndex = 26;
            this.group號碼.TabStop = false;
            this.group號碼.Text = "號碼";
            // 
            // lblPlay10
            // 
            this.lblPlay10.BackColor = System.Drawing.Color.White;
            this.lblPlay10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay10.Location = new System.Drawing.Point(347, 40);
            this.lblPlay10.Name = "lblPlay10";
            this.lblPlay10.Size = new System.Drawing.Size(31, 30);
            this.lblPlay10.TabIndex = 34;
            this.lblPlay10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay9
            // 
            this.lblPlay9.BackColor = System.Drawing.Color.White;
            this.lblPlay9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay9.Location = new System.Drawing.Point(310, 23);
            this.lblPlay9.Name = "lblPlay9";
            this.lblPlay9.Size = new System.Drawing.Size(31, 30);
            this.lblPlay9.TabIndex = 33;
            this.lblPlay9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay8
            // 
            this.lblPlay8.BackColor = System.Drawing.Color.White;
            this.lblPlay8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay8.Location = new System.Drawing.Point(273, 40);
            this.lblPlay8.Name = "lblPlay8";
            this.lblPlay8.Size = new System.Drawing.Size(31, 30);
            this.lblPlay8.TabIndex = 32;
            this.lblPlay8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay7
            // 
            this.lblPlay7.BackColor = System.Drawing.Color.White;
            this.lblPlay7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay7.Location = new System.Drawing.Point(236, 23);
            this.lblPlay7.Name = "lblPlay7";
            this.lblPlay7.Size = new System.Drawing.Size(31, 30);
            this.lblPlay7.TabIndex = 31;
            this.lblPlay7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay6
            // 
            this.lblPlay6.BackColor = System.Drawing.Color.White;
            this.lblPlay6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay6.Location = new System.Drawing.Point(199, 40);
            this.lblPlay6.Name = "lblPlay6";
            this.lblPlay6.Size = new System.Drawing.Size(31, 30);
            this.lblPlay6.TabIndex = 30;
            this.lblPlay6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay5
            // 
            this.lblPlay5.BackColor = System.Drawing.Color.White;
            this.lblPlay5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay5.Location = new System.Drawing.Point(162, 22);
            this.lblPlay5.Name = "lblPlay5";
            this.lblPlay5.Size = new System.Drawing.Size(31, 30);
            this.lblPlay5.TabIndex = 29;
            this.lblPlay5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay4
            // 
            this.lblPlay4.BackColor = System.Drawing.Color.White;
            this.lblPlay4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay4.Location = new System.Drawing.Point(125, 40);
            this.lblPlay4.Name = "lblPlay4";
            this.lblPlay4.Size = new System.Drawing.Size(31, 30);
            this.lblPlay4.TabIndex = 28;
            this.lblPlay4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay3
            // 
            this.lblPlay3.BackColor = System.Drawing.Color.White;
            this.lblPlay3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay3.Location = new System.Drawing.Point(88, 22);
            this.lblPlay3.Name = "lblPlay3";
            this.lblPlay3.Size = new System.Drawing.Size(31, 30);
            this.lblPlay3.TabIndex = 27;
            this.lblPlay3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlay2
            // 
            this.lblPlay2.BackColor = System.Drawing.Color.White;
            this.lblPlay2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPlay2.Location = new System.Drawing.Point(51, 40);
            this.lblPlay2.Name = "lblPlay2";
            this.lblPlay2.Size = new System.Drawing.Size(31, 30);
            this.lblPlay2.TabIndex = 26;
            this.lblPlay2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textMoney
            // 
            this.textMoney.Location = new System.Drawing.Point(943, 118);
            this.textMoney.Name = "textMoney";
            this.textMoney.Size = new System.Drawing.Size(158, 27);
            this.textMoney.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(940, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "金額";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.玩法說明ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1132, 24);
            this.menuStrip1.TabIndex = 29;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 玩法說明ToolStripMenuItem
            // 
            this.玩法說明ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本玩法ToolStripMenuItem,
            this.超級獎號ToolStripMenuItem,
            this.猜大小ToolStripMenuItem,
            this.猜單雙ToolStripMenuItem,
            this.按鈕說明ToolStripMenuItem});
            this.玩法說明ToolStripMenuItem.Name = "玩法說明ToolStripMenuItem";
            this.玩法說明ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.玩法說明ToolStripMenuItem.Text = "玩法說明";
            // 
            // 基本玩法ToolStripMenuItem
            // 
            this.基本玩法ToolStripMenuItem.Name = "基本玩法ToolStripMenuItem";
            this.基本玩法ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.基本玩法ToolStripMenuItem.Text = "基本玩法";
            this.基本玩法ToolStripMenuItem.Click += new System.EventHandler(this.基本玩法ToolStripMenuItem_Click);
            // 
            // 超級獎號ToolStripMenuItem
            // 
            this.超級獎號ToolStripMenuItem.Name = "超級獎號ToolStripMenuItem";
            this.超級獎號ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.超級獎號ToolStripMenuItem.Text = "超級獎號";
            this.超級獎號ToolStripMenuItem.Click += new System.EventHandler(this.超級獎號ToolStripMenuItem_Click);
            // 
            // 猜大小ToolStripMenuItem
            // 
            this.猜大小ToolStripMenuItem.Name = "猜大小ToolStripMenuItem";
            this.猜大小ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.猜大小ToolStripMenuItem.Text = "猜大小";
            this.猜大小ToolStripMenuItem.Click += new System.EventHandler(this.猜大小ToolStripMenuItem_Click);
            // 
            // 猜單雙ToolStripMenuItem
            // 
            this.猜單雙ToolStripMenuItem.Name = "猜單雙ToolStripMenuItem";
            this.猜單雙ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.猜單雙ToolStripMenuItem.Text = "猜單雙";
            this.猜單雙ToolStripMenuItem.Click += new System.EventHandler(this.猜單雙ToolStripMenuItem_Click);
            // 
            // 按鈕說明ToolStripMenuItem
            // 
            this.按鈕說明ToolStripMenuItem.Name = "按鈕說明ToolStripMenuItem";
            this.按鈕說明ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.按鈕說明ToolStripMenuItem.Text = "按鈕說明";
            this.按鈕說明ToolStripMenuItem.Click += new System.EventHandler(this.按鈕說明ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1132, 655);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textMoney);
            this.Controls.Add(this.group號碼);
            this.Controls.Add(this.btn玩家號碼顯示);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl倒數);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.listBoxInformation);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Lotto";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.group號碼.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPrice;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.Label lblNum4;
        private System.Windows.Forms.Label lblNum5;
        private System.Windows.Forms.Label lblNum6;
        private System.Windows.Forms.Label lblNum7;
        private System.Windows.Forms.Label lblNum8;
        private System.Windows.Forms.Label lblNum9;
        private System.Windows.Forms.Label lblNum10;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblNum20;
        private System.Windows.Forms.Label lblNum19;
        private System.Windows.Forms.Label lblNum18;
        private System.Windows.Forms.Label lblNum17;
        private System.Windows.Forms.Label lblNum16;
        private System.Windows.Forms.Label lblNum15;
        private System.Windows.Forms.Label lblNum14;
        private System.Windows.Forms.Label lblNum13;
        private System.Windows.Forms.Label lblNum12;
        private System.Windows.Forms.Label lblNum11;
        private System.Windows.Forms.Button btnMore;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt包牌次數;
        private System.Windows.Forms.RadioButton radio猜小;
        private System.Windows.Forms.RadioButton radio猜大;
        private System.Windows.Forms.RadioButton radio猜和;
        private System.Windows.Forms.RadioButton radio猜雙數;
        private System.Windows.Forms.RadioButton radio猜單數;
        private System.Windows.Forms.Timer time電腦選號;
        private System.Windows.Forms.Label lbl倒數;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radio猜小雙;
        private System.Windows.Forms.RadioButton radio猜小單;
        private System.Windows.Forms.Button btn電腦選碼;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox combo幾星電腦選碼;
        private System.Windows.Forms.Button btn兌獎;
        private System.Windows.Forms.Button btn玩家號碼顯示;
        private System.Windows.Forms.RadioButton radio不玩;
        private System.Windows.Forms.CheckBox chk超級獎號;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox combo基本星數;
        private System.Windows.Forms.Label lblPlay1;
        private System.Windows.Forms.GroupBox group號碼;
        private System.Windows.Forms.Label lblPlay10;
        private System.Windows.Forms.Label lblPlay9;
        private System.Windows.Forms.Label lblPlay8;
        private System.Windows.Forms.Label lblPlay7;
        private System.Windows.Forms.Label lblPlay6;
        private System.Windows.Forms.Label lblPlay5;
        private System.Windows.Forms.Label lblPlay4;
        private System.Windows.Forms.Label lblPlay3;
        private System.Windows.Forms.Label lblPlay2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radio猜大小不玩;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 玩法說明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基本玩法ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 超級獎號ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 猜大小ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 猜單雙ToolStripMenuItem;
        protected System.Windows.Forms.ListBox listBoxInformation;
        protected System.Windows.Forms.TextBox textMoney;
        private System.Windows.Forms.ToolStripMenuItem 按鈕說明ToolStripMenuItem;
        public System.Windows.Forms.CheckBox chk超級包牌獎號;
    }
}

